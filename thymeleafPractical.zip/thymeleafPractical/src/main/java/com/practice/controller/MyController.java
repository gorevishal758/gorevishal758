package com.practice.controller;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@ Controller
public class MyController {
	
	@RequestMapping(value="/about",method=RequestMethod.GET)
	public String about(Model m)
	{
		System.out.println("inside about handler");
		m.addAttribute("name","vishal");
		m.addAttribute("currentDate",new Date().toLocaleString());
		return "about";
	}

	//handling iteration
	
	@GetMapping("/example-loop")
	public String iterateHandler(Model mod)
	{
		//create list ,set of collection
		List<String> names = List.of("ankit","laxmi","rahul","ram","john");
		
		mod.addAttribute("names", names);
		return "iterate";
	}
	// handler for conditional statements
	@GetMapping("/condition")
	public String conditionHandler(Model m)
	{
		m.addAttribute("isActive",true); //use elvis operator
		m.addAttribute("gender","F"); //use for if unless operator
		List<Integer> list = List.of(22,23,24,25,26);
		//List<Integer> list = List.of(22);
		//List<Integer> list = List.of();
		m.addAttribute("mylist",list);
		System.out.println("condition handle working.....");
		
		
		return "condtion";
	}
	//handler for including fragments
	@GetMapping("/service")
	public String servicesHandler(Model m)
	{
		//processing logic
		m.addAttribute("title","Rich dad poor dad");
		m.addAttribute("subtitle",LocalDateTime.now().toString());
		return "service";
	}
	
	@GetMapping("/newabout")
	public String newAbout()
	{
		return "aboutnew";
	}
	
	@GetMapping("/contact")
	public String newcontact()
	{
		return "contact";
	}
}
