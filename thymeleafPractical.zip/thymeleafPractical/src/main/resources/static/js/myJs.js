console.log("this is massage of console")
//alert("js is activated")