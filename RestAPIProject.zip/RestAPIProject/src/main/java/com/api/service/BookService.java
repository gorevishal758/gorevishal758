package com.api.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.api.entities.Book;

@Service
public class BookService {
	private static List<Book> list = new ArrayList<>();

	static {

		
		  list.add(new Book(12,"java","XYZ")); list.add(new Book(13,"python","ABC"));
		  list.add(new Book(14,"SQL","PQR"));
		 

	}

	// get all books
	public List<Book> getAllBooks() {
		return list;
	}

	public Book getBookById(int id) {
		Book book = null;

		try {
			book = list.stream().filter(e -> e.getId() == id).findFirst().get();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return book;

	}

	// adding book
	public Book addBook(Book b) {
		list.add(b);
		return b;
	}

	// delete book
	public void deleteBook(int bid) // if true then filter else not filter
	{
		list = list.stream().filter(b -> b.getId() != bid).collect(Collectors.toList());
	}

	// update book
	public void updateBook(Book book, int bookId) {
		list.stream().map(b -> { // map use for to perform operation like add in list

			if (b.getId() == bookId) {
				b.setAuthor(book.getAuthor());
				b.setTitle(book.getTitle());
			}

			return b;
		}).collect(Collectors.toList());
	}
}
