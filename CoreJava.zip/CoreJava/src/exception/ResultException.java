package exception;

public class ResultException extends Exception {
	
	public ResultException(String str)
	{
		super(str);
	}

}
