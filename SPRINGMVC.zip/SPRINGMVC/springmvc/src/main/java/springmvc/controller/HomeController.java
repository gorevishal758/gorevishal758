package springmvc.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	
	@RequestMapping(path="/home" ,method=RequestMethod.GET)
	public String home(Model model)
	{
		System.out.println("Hello This is home URL");
		model.addAttribute("name","Vishal Gore");
		model.addAttribute("id", "789999");
		
		List<String> f =new ArrayList<String>();
		f.add("rahul");
		f.add("ganesh");
		f.add("arjun");
		f.add("jethalal");
		model.addAttribute("f",f);
		return "index";
	}
	@RequestMapping("/about")
	public String about()
	{
		System.out.println("This is about page controller");
		return "about";
	}
	@RequestMapping("/help")
	public ModelAndView help()
	{
		System.out.println("help page loading");
		//creating model and view object
		ModelAndView m=new ModelAndView();
		//setting data
		m.addObject("name","RAM");
		m.addObject("rollnum", 120130);
		LocalDateTime now=LocalDateTime.now();
		m.addObject("time",now);
		
		//marks
		List <Integer> l=new ArrayList<Integer>();
		l.add(80);
		l.add(90);
		l.add(75);
		l.add(87);
		m.addObject("marks",l);
		//setting view name
		m.setViewName("help");
		return m;
	}
	


}
