package springmvc.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import springmvc.model.User;
import springmvc.service.UserService;
@Controller
public class ContactController {
	@Autowired
	private UserService userService;
	@ModelAttribute
	public void CommonDataForModel(Model m) {
		
		//We can use this common method 
		m.addAttribute("Header","Learn code with vishal");
		m.addAttribute("Desc","Home for programmer");
		
	}
	@RequestMapping("/contact")
	public String showform(Model m)
	{
		/*
		 * m.addAttribute("Header","Learn code with vishal");
		 * m.addAttribute("Desc","Home for programmer");
		 */
		return "contact";
	}
	 @RequestMapping(path="/processform",method = RequestMethod.POST)
	 public String handleForm(@ModelAttribute User user, Model model )
	 {
	 
			/*
			 * model.addAttribute("Header","Learn code with vishal");
			 * model.addAttribute("Desc","Home for programmer");
			 */	 
	 System.out.println(user);
	 this.userService.createUser(user);
	 
	 	return "success";
	 }
	
}
// this code is complicated and need to write lots of code so we use model attribute annotation
/* @RequestMapping(path="/processform",method = RequestMethod.POST)
public String handleForm(@RequestParam("email") String email ,@RequestParam("username") String username,
		@RequestParam("password") String password, Model model)
{
User user=new User();
user.setEmail(email);
user.setUsername(username);
user.setPassword(password);
System.out.println(user);
	
/*
 * //proces model.addAttribute("username",username);
 * model.addAttribute("email",email); model.addAttribute("password",password);
 */
/*model.addAttribute("user",user);
	
	return "success";
}*/