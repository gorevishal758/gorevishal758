package com.myapp.dao;

import org.springframework.data.repository.CrudRepository;

import com.myapp.entities.Book;

public interface BookRepo extends CrudRepository<Book, Integer> {
	public Book findById(int id);
}
