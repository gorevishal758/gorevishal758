package com.myapp.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myapp.dao.BookRepo;
import com.myapp.entities.Book;

@Service
public class BookService {
	
	@Autowired
	private BookRepo bookRepo;
	
	public List<Book> getAllBooks()
	{
		List<Book> list=(List<Book>)this.bookRepo.findAll();
		return list;
	}
	
	public Book getBookById(int id) {
		Book book = null;

		try {
			book=this.bookRepo.findById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return book;

	}

	// adding book
	public Book addBook(Book b) {
		Book result=bookRepo.save(b);
		return result;
	}

	// delete book
	public void deleteBook(int bid) // if true then filter else not filter
	{
		bookRepo.deleteById(bid);
	}

	// update book
	public void updateBook(Book book, int bookId) {
		book.setId(bookId);
		bookRepo.save(book);
	}
}
