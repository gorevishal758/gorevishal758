package com.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectWithMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectWithMySqlApplication.class, args);
		
		System.out.println(".................run succesfully");
	}

}
