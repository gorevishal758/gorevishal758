package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.app.model.User;
import com.app.service.UserService;
import com.app.service.UserServiceImpl;

@Controller
public class HomeController {

	@Autowired(required = true)
	private UserService userService;

	@GetMapping("/")
	public String index() {
		return "index";

	}

	@GetMapping("/signin")
	public String login() {
		return "login";

	}

	@GetMapping("/register")
	public String register() {
		return "register";
	}

	@PostMapping("/createUser")
	public String createUser(@ModelAttribute User user,HttpSession session) {
		boolean f = userService.checkEmail(user.getEmail());    // modelAtribute use for binding user inputs

		if (f) {
			//System.out.println("Email already Exist");
			session.setAttribute("msg", "Email already Exist");
		} else {
			User user1 = userService.createUser(user);
			if (user1 != null) {
				//System.out.println("Register successfully");
				session.setAttribute("msg", "Register successfully");
			} else {
				System.out.println("Something error on server");
				session.setAttribute("msg", "Something wrong on server");
			}

		}

		return "redirect:/register";

	}
	
	
	
	
}
