package com.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.app.model.User;

public interface UserRepo extends JpaRepository<User, Integer> {

	public boolean existsByEmail(String email);  //User Repo use to save upadte delete
	public User findByEmail(String email);
}
