package com.app.dao;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.app.entity.User;

public class UserDaoImpl extends JdbcDaoSupport implements UserDao {

	@Autowired
	DataSource datasource;
	
	@PostConstruct
	private void intialize()
	{
		setDataSource(datasource);
	}
	@Override
	public User getUserById(String userId) {


		return null;
	}
	
	

}
