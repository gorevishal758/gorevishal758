package com.app.dao;

import com.app.entity.User;

public interface UserDao {

	User getUserById(String userId);
}
