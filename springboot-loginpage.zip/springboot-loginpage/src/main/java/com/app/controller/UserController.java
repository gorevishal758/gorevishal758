package com.app.controller;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.entity.User;
import com.app.repo.UserRepo;
@Controller
public class UserController {
	@Autowired
	private UserRepo repo;
	@RequestMapping("/")  					    /* @RequestMapping is used at the class level 
                       												while @GetMapping is used to connect the methods*/
	public String login(Model model) {                          //model is use to add attributes 
		User user=new User();
		model.addAttribute("user",user);
		return "login" ;
	}
	@PostMapping("/userLogin")
	public String loginUser(@ModelAttribute("user") User user)
	{
	   String userId=user.getUserId();
	  
	   
		Optional<User> userdata =repo.findById(userId);
		

		if((user.getPassword().equals(userdata.get().getPassword())))
		{
			return "home";
		}
		else
		{
			return "errorpage";
		}
	}
	
	@PostMapping("/userLogout")
	public String logoutUser(@ModelAttribute("user") User user)
	{
	  
			return "login";	
		
	}
}
