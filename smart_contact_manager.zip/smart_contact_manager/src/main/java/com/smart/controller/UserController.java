package com.smart.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.smart.dao.ContactRepo;
import com.smart.dao.UserRepo;
import com.smart.helper.Message;
import com.smart.model.Contact;
import com.smart.model.User;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private ContactRepo contactRepo;
	
	//method for adding common data to response
	@ModelAttribute
	public void addCommonData(Model m,Principal p)
	{
		String username=p.getName();
		System.out.println("USERNAME :"+username);
		
		User user = userRepo.getUserByUserName(username);
		//get user using username(Email)
		System.out.println("USER "+user);
		
		m.addAttribute("user", user);
	}
	
	
	@GetMapping("/index")
	public String dashboard(Model m,Principal p)
	{
		m.addAttribute("title","user-dashboard");
		return "normal/user_dashboard";
	}
	
	//open add form handler

	@GetMapping("/add-contact")
	public String openAddHandler(Model m)
	{
		m.addAttribute("title","add-contact");
		m.addAttribute("contact",new Contact());
		
		return "normal/add_contact_form";
	}
	
	//processing add contact form
	@PostMapping("/process-contact")
	public String processContact(@ModelAttribute Contact contact,
		@RequestParam("profileImage") MultipartFile file,Principal p,HttpSession session)
	{
	try{
		String name = p.getName();
		User user = this.userRepo.getUserByUserName(name);
		//processing and uploading file...
		
		if(file.isEmpty())
		{
			//if the file is empty then try your message
			System.out.println("File is empty...");
			contact.setImage("contact.png");
			
		}
		else
		{
			//file to folder update name to contact
			contact.setImage(file.getOriginalFilename());
			
			File file2 = new ClassPathResource("static/img").getFile();
			Path path = Paths.get(file2.getAbsolutePath()+File.separator+file.getOriginalFilename());
			
			Files.copy(file.getInputStream(),path,StandardCopyOption.REPLACE_EXISTING);
			
			System.out.println("File is uploaded...");
		}
		user.getContact().add(contact);
		contact.setUser(user);
		User save = this.userRepo.save(user);
		System.out.println("Added to database successfully "+save);
		
		
		System.out.println("Data"+contact);
		
		//message success...........
		
		session.setAttribute("message",new Message("your contact is added..","success"));
		
	}
	catch(Exception e)
	{
		System.out.println("ERROR"+e.getMessage());
		//error message
		session.setAttribute("message",new Message("something went wrong try again..","danger"));
		
	}

	return "normal/add_contact_form";
	}
	//show contact
	/// 
	@GetMapping("/show-contact/{page}")
	public String showContact(@PathVariable("page") Integer page, Model m,Principal p) {
		
		m.addAttribute("title", "show user contact");
		
		/*
		 * // use principal here this another option to show info.. ,Principal p // send
		 * contact list.. String name = p.getName(); User userByUserName =
		 * this.userRepo.getUserByUserName(name);
		 * 
		 * List<Contact> contact = userByUserName.getContact();
		 */
		String userName=p.getName();
		User user = this.userRepo.getUserByUserName(userName);
		
		//currentpage-page
		//contact per page 5
		Pageable pageable = PageRequest.of(page,5);
		//List<Contact> contact = this.contactRepo.findContatByUser(user.getId());
		Page <Contact> contact = this.contactRepo.findContatByUser(user.getId(),pageable);
		
		m.addAttribute("contact",contact);
		m.addAttribute("currentPage",page);
		m.addAttribute("totalPages",contact.getTotalPages());
		return "normal/show_contacts";
	}
	//showing specific contact details
	@GetMapping("/{id}/contact")
	public String showContactDetails(@PathVariable("id") Integer id,Model model,Principal p) {
		Optional<Contact> findById = this.contactRepo.findById(id);
		Contact contact = findById.get();
		
		String username=p.getName();
		User user = this.userRepo.getUserByUserName(username);
		
		if(user.getId()==contact.getUser().getId())
		{
			model.addAttribute("contact", contact);
			model.addAttribute("title",contact.getName());
		}
		System.out.println("CID"+id);
		return"normal/contact_details";
	}
	
	//delete contact handler
	@GetMapping("/delete/{id}")
	public String deleteContact(@PathVariable ("id") Integer id,Model m,HttpSession session,Principal p)
	{
		Optional<Contact> contactOptional = this.contactRepo.findById(id);
		Contact contact = contactOptional.get();
		//check..perform
		
		String username=p.getName();
		User user = this.userRepo.getUserByUserName(username);
		
		if(user.getId()==contact.getUser().getId())
		{
			m.addAttribute("contact", contact);
			m.addAttribute("title",contact.getName());
			//contact.setUser(null);//contact unlinked with user  one to many relationship cascadeType.All
			
			//photo remove 
			//img
			//contact.getImage() assignment
			
			//this.contactRepo.delete(contact);
			user.getContact().remove(contact);
			this.userRepo.save(user);
			session.setAttribute("message",new Message("contact deleted successfully..","success"));
		}
		
		return "redirect:/user/show-contact/0";
	}
	//update form handler
	
	@PostMapping("/update-contact/{id}")
	public String updateUser(@PathVariable("id") Integer id, Model m) {
		
		m.addAttribute("title","update-contact");
		Contact contact = this.contactRepo.findById(id).get();
		m.addAttribute("contact", contact);
		
		return "normal/update_form";
	}
	
	//update contact back-end handler
	
	@RequestMapping(value = "/process-update",method = RequestMethod.POST)
	public String updateHandler(@ModelAttribute Contact contact,@RequestParam("profileImage") MultipartFile file,Model m,HttpSession session,Principal p) {
		
		try {
			//old contact details
			Contact oldcontact = this.contactRepo.findById(contact.getId()).get();
			
			//image
			if(!file.isEmpty())
			{
				//file work
				//rewrite
				// delete old photo 
				
				File deletefile = new ClassPathResource("static/img").getFile();
				File file1=new File(deletefile,oldcontact.getImage());
				file1.delete();
				//update new file

				File file2 = new ClassPathResource("static/img").getFile();
				Path path = Paths.get(file2.getAbsolutePath()+File.separator+file.getOriginalFilename());
				
				Files.copy(file.getInputStream(),path,StandardCopyOption.REPLACE_EXISTING);
				contact.setImage(file.getOriginalFilename());
				
			}
			else
			{
				contact.setImage(oldcontact.getImage());
			}
			
			User user=this.userRepo.getUserByUserName(p.getName());
			contact.setUser(user);
			
			this.contactRepo.save(contact);
			session.setAttribute("message", new Message("your contact updated successfully..","success"));
			
		} catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("CONTACT NAME :"+contact.getName());
		
		
		
		return "redirect:/user/"+contact.getId()+"/contact";
	}
	
	//profile handler
	@GetMapping("/profile")
	public String userProfile(Model m)
	{
		m.addAttribute("titel", "profile-page");
		return "normal/profile";
	}
}
