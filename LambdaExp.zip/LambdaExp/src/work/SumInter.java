package work;

public interface SumInter {
	public abstract int sum(int a,int b);

}
