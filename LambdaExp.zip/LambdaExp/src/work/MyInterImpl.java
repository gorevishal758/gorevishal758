package work;

public class MyInterImpl implements MyInterface{

	@Override
	public void sayHello() {
		
		System.out.println("I am saying hello from myInterImpl");
	}

}
