package work;

public interface LengthInter {
	public abstract int getLength(String str);
		
	}


