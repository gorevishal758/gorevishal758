package com.practice.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller

public class TestController {

	@RequestMapping("/test")
	@ResponseBody  // use for print msg 
	public String Handler()
	{
		return "just for testing";
	}
}
