package com.practice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.practice.entities.User;

public interface UserRepo extends CrudRepository<User, Integer> {

	public List<User> findByName(String name);

	// Keyword supported by JPA we can use all this method if we dont want to use
	// Queries
	public List<User> findByNameAndCity(String name, String city);

	public List<User> findByNameStartingWith(String prefix);

	public List<User> findByNameEndingWith(String suffix);

	public List<User> findByNameContaining(String words);

	@Query("select u FROM User u") // JPQL query is Java Persistence Query Language
	public List<User> getAllUser();

	// u is alias
	@Query("select u from User u WHERE u.name=:n and u.city=:c") // parameterized query
	public List<User> getUserByName(@Param("n") String name,@Param("c") String city);

	
	//native query or SQL query
	
	@Query(value="select * from user", nativeQuery=true)
	public List<User> getUsers();
}
