package com.practice;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.ResponseBody;

import com.practice.dao.UserRepo;
import com.practice.entities.User;

@SpringBootApplication
public class UserPractice {

	public static void main(String[] args) {
		
	ApplicationContext context=	SpringApplication.run(UserPractice.class, args);
	UserRepo userRepo= context.getBean(UserRepo.class);
	
	/*
	 * User user=new User(); user.setName("vishal gore"); user.setCity("Wardha");
	 * user.setStatus("I am java programmer");
	 * 
	 * User user1=userRepo.save(user); System.out.println(user1);
	 */
	
	// create object of user
	User user1 =new User();
	
	user1.setName("uttam");
	user1.setCity("Delhi");
	user1.setStatus("python programmer");
	
	User user2 =new User();
	
	user2.setName("ankit");
	user2.setCity("mumbai");
	user2.setStatus("SQL programmer");
	
	/* saving single user
	 * userRepo.save(user2); System.out.println(user2);
	 */
	
	
	  // save multiple object CREATE
	  
		/*
		 * List<User> users=List.of(user1,user2); Iterable<User> result =
		 * userRepo.saveAll(users);
		 * 
		 * result.forEach(user->{
		 * 
		 * System.out.println(user);
		 * 
		 * });
		 */
	
	/*
	 * //UPDATE USER OF ID 3 
	 * Optional<User> update = userRepo.findById(3); User user
	 * = update.get();
	 * 
	 * user.setName("ankit tiwari"); User save = userRepo.save(user);
	 * System.out.println(save);
	 */
	
	//How to get data
	// findById(id)- return optional containing your data
	
//	Iterable<User> itr = userRepo.findAll();
//	Iterator<User> iterator = itr.iterator();
	
	/* collect all data list
	 * while(iterator.hasNext()) { User user=iterator.next();
	 * System.out.println(user); }
	 */
	//OR
	/*
	 * itr.forEach(new Consumer<User>() {
	 * 
	 * @Override public void accept(User t) { // TODO Auto-generated method stub
	 * System.out.println(t); }
	 * 
	 * });
	 */
	
	//OR best option  lamda function
	
//	itr.forEach(user->{System.out.println(user);});
	
	
	
	///DELETE
	
	/*
	 * // delete single entity 
	 * userRepo.deleteById(3);
	 * System.out.println("Deleted succesfully");
	 */
	
	// want to remove all use this 
	/*
	 * Iterable<User> alluser = userRepo.findAll();
	 * alluser.forEach(user->{System.out.println(user);
	 * 
	 * userRepo.deleteAll(alluser);
	 * 
	 * });
	 */
	
	//List<User> users = userRepo.findByName("ankit");
	/*
	 * List<User> users = userRepo.findByNameAndCity("uttam","Delhi");
	 * 
	 * users.forEach(e->{System.out.println(e);});
	 */
	
	// using JPQL queries
	/*List<User> allUser=userRepo.getAllUser();
	allUser.forEach(e->{System.out.println(e);});
	
	List<User> userByName = userRepo.getUserByName("vishal","wardha");
	
	System.out.println("-------------------------------------------------------------- ");*/
	
	/*
	userByName.forEach(u->{System.out.println(u);});
	
	System.out.println("-------------------------------------------------");
	userRepo.getUsers().forEach(m->{System.out.println(m);}); */
}
}
